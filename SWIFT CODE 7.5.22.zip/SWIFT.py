import math
import random
from dice_activity import dice_roll
try:
    idesign = 0
    numberdesign = 7
    while idesign < numberdesign + 1:
        idesign = idesign + 1
        print("_SWIFT_" * idesign)
    print("hi i am SWIFT your personal artificial intelligence")

    name_input = input('to get the best experience please tell me your name\nNAME:')
    name_split = name_input.split(" ")
    name = name_split[0]
    lastname = name[1]

    class GreetUser:
        def morning(self):
            print(f"Good Morning, {name}")

        def noon(self):
            print(f"Good Afternoon, {name}")

        def eve(self):
            print(f"Good Evening, {name}")

        def night(self):
            print(f"Good Night, {name}")


    greeting = GreetUser()
    time = int(input("time>>"))
    if 6 <= time < 12:
        greeting.morning()
    if 12 <= time <= 17:
        greeting.noon()
    if 17 <= time <= 21:
        greeting.eve()
    if 21 <= time <= 6:
        greeting.night()
        
    print(f"hi {name}, now i am ready to operate there are a lot of things"
          f"that i can do to have a look at all of them enter 'help'")
    ifhelp = input("do you need any help?>")
    if ifhelp.upper() == "HELP":
        print("""
        1) count to 'n' numbers
        2) ask about my creator
        3) ask about the digits of pi
        4)say hi 
        5) ask about monument 'the stonehenge' 
        6)convert into emoji
        7)Play Duke
        8)Play Guess game 
               """)
    else:
        print("to start enter in the arrowhead below")
    command: str = input("to start press enter to exit type 'exit ")
    while command.upper() != "EXIT":
        cmd = input(">>").upper()
        print(f"input = <{cmd}>\n ")
        if cmd == "WHAT IS THE VALUE OF PI":
            print(f"the value of pi is approximately {math.pi}")
        if cmd == "WHO IS YOUR CREATOR":
            print("i was created by a man called Bakul Takthar who is a \n"
                  "nexus being he created me by writing some fancy lines of \n"
                  "code on his computer")
        if cmd == "COUNT TO A NUMBER":
            no = int(input("what is your number>>"))
            for nom in range(no + 1):
                print(nom)
        if cmd == "FLIP A COIN":
            outcomes_flip_a_coin = [1, 2]
            result = random.choice(outcomes_flip_a_coin)
            if result == 1:
                result = "heads"
            if result == 2:
                result = "tails"
            print(result)
        if cmd == "ROLL TWO DICES":
            dice_roll()
        if cmd == "ROLL A DICE":
            total_outcomes = [1,2,3,4,5,6]
            dice_roll_one = random.choice(total_outcomes)
            print(dice_roll_one)
        if cmd == "CONVERT INTO EMOJI":
            print("enter your sentence below")
            message = input(">>")
            words = message.split(" ")
            emojis = {
                ":)": "😊",
                ":(": "😭",
                ";)": "😉"
            }
            output = ""
            for word in words:
                output += emojis.get(word, word) + " "
            print(output)
        if cmd == "LAUNCH DUKE":
            print("""
                XXXXXX        XX     XX      XX     XX     XXXXXXXX
               XX    XX      XX     XX      XX  XXX       XX
              XX    XX      XX     XX      XXXX          XXXXXX
             XX    XX      XX     XX      XX  XXX       XX
            XXXXXX          XXXXX       XX     XX      XXXXXXXX
            """)
            cmduke = input("to start press enter to exit press U >>")
            print("hi welcome to duke the best car game")
            name2 = name_input
            print(f"your name is {name_input}")
            print("to get familiar with controls type 'help' or 'HELP' ")
            print(f"there are a heck a lot of things you can do with your car{name_input}"
                  f" lets "
                  f"get going")
            while cmduke.upper != "U":
                started = False
                command = str(input("DUKE play> ")).upper()
                if command.upper() == 'HELP':
                    print('''
                 to enter the car press f 
                 to leave the car press f again
                 to start the car press e
                 to stop the car press q
                 to move forward press w
                 to move backwards press s
                 to turn right press d 
                to turn left press a
                to quit the game press u''')
                inside_car = False
                if str(command.upper()) == "F":
                    if inside_car:
                        print("left the car")
                        inside_car = False
                    else:
                        print("entered the car")
                        inside_car = True
                if str(command.upper()) == "W":
                    print("moved forward")
                if str(command.upper()) == "S":
                    print("moved backwards")
                if str(command.upper()) == "E":
                    if started:
                        print("car already started")
                    else:
                        print("started the car")
                        started = True
                if str(command.upper()) == "D":
                    print("turned right")
                if str(command.upper()) == "L":
                    print("turned left")
                if command.upper() == "Q":
                    if started:
                        print("car stopped")
                        started = False
                    else:
                        print("car already stopped")
                if str(command.upper()) == "A":
                    print("turned left")
                if str(command.upper()) == "U":
                    print("exited the game")
                    break
        if cmd == "PLAY GUESS GAME":
            print("to start press G to leave press U")
            start_guessing = input("GUESS game>>")
            if start_guessing == "U":
                print("left")
            else:
                print("""
                game started 
                rules
                
                1) you only get 3 tries 
                2)if you fail to guess the correct  number all three times you 
                fail
                3)the correct number will be displayed after the game has 
                ended
                """)
            secret_number = 7
            guess_count = 0
            guess_limit = 3
            try:
                while guess_count < guess_limit:
                    guess = int(input('GUESS:'))
                    guess_count += 1
                    if guess == secret_number:
                        print('YOU WON!')
                        break
                    else:
                        print("you failed\n the correct number was 7")

            except ValueError:
                print("invalid input")
        if cmd == "LAUNCH CALCULATOR":
            
            print("claculator started.....")
            print(""" 
                  + = addition
                  - = subtraction
                  * = multiplication
                  / = division
                  ^ = raised to the power 
                  *NOTE -- EACH INPUT MUST CONTAIN SPACE BETWEEN THE VALUES AND
                  THE OPERATOR*
                  EX = NUMBER1(SPACE)OPERATOR(SPACE)NUMBER2
                  """)
            input_for_calculator = input("calculator>>")
            
            while input_for_calculator != "exit":
                input_for_calculator2 = input("clculator enter your problem>>")
                calcu_info = input_for_calculator2.split(" ")
                if calcu_info[1] == "+":
                    print(int(calcu_info[0]) + int(calcu_info[2]))
                if calcu_info[1] == "*":
                    print(int(calcu_info[0]) * int(calcu_info[2]))
                if calcu_info[1] == "-":
                    print(int(calcu_info[0]) - int(calcu_info[2]))
                if calcu_info[1] == "/":
                    print(int(calcu_info[0]) / int(calcu_info[2]))
                if calcu_info[1] == "^":
                    print(int(calcu_info[0]) ** int(calcu_info[2]))
                if input_for_calculator2.upper() == "EXIT":
                    break
            
                
        if cmd == "what is the stonehenge":
            print(
                '''the stonehenge is an ancient monument having large 
            stones placed in a circular shape each stone of the 
            monument is super heavy and it remains a mystery till now
            how the stones were placed there the monument is 
            perfectly alligned to show the first sunrise of summer solstice''')
        if cmd == "BYE":
            print("bye for now but not for long")
            break
except ValueError:
    print("input should be in words")
    

