def calculate_shipping():
    print("printed the calculation of shipping")
