class Mammal:
    def walk(self):
        print("walk")
    def poop(self):
        print('pooped')


class Doge(Mammal):
    def pee(self):
        print("peed")


doge = Doge()
doge.poop()
doge.pee()