# tuples cant be modified you can just get information from tuples
number = (7, 5, 8, 9, 10)
print(number.index(7))
print(number.count(7))
# unpacking
coordinates = (7, 9, 11)
x, y, z = coordinates
print(f'{x} , {y}, {z}')
coordinate = [6, 8, 10]
x, y, z = coordinate
print(f'{x} , {y}, {z}')