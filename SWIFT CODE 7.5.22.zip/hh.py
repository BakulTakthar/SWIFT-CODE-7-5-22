# nested loop
numbers = [2, 2, 2, 2, 6]
for line1 in numbers:
    pqr = "X" * line1
    print(pqr)
