def morning():
    print("good morning")
def night():
    print("good night")
