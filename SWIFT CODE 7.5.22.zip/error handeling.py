try:
    age = int(input("age>>"))
    power = 45000
    josh = power / age
    print(age)
except ValueError:
    print("unable to process invalid input")
except ZeroDivisionError:
    print("age cannot be zero (0)")
# exit code 0 = program completed with no error
# exit code other than 0 is program had an error
