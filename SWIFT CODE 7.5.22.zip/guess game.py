secret_number = 7
guess_count = 0
guess_limit = 3
try:
    while guess_count < guess_limit:
        guess = int(input('GUESS:'))
        guess_count += 1
        if guess == secret_number:
            print('YOU WON!')
            break
        else:
            print("you failed\n the correct number was 7")
except ValueError:
    print("invalid input")

