import math
try:
    print("hi i am chalexa your personal artificial intelligence")
    name = input('to get the best experience please tell me your name\nNAME:')
    print(f"hi {name}, now i am ready to operate there are a lot of things"
          f"that i can do to have a look at all of them enter 'help'")
    ifhelp = input("do you need any help?>")
    if ifhelp.upper() == "HELP":
        print("1) count to 'n' numbers \n"
              "2) ask about my creator\n"
              "3) ask about the digits of pi\n"
              "4)say hi \n"
              "5) ask about monument the stonehenge \n ")
    else:
        print("to start enter in the arrowhead below")
    command: str = input("to start press enter to exit type 'exit ")
    while command.upper() != "EXIT":
        cmd: str = input(">>")
        print(f"input = <{cmd}>\n ")
        if cmd.upper() == "WHAT IS THE VALUE OF PI":
            print(f"the value of pi is approximately {math.pi}")
        if cmd.upper() == "WHO IS YOUR CREATOR":
            print("i was created by a man called Bakul Takthar who is a \n"
                  "nexus being he created me by writing some fancy lines of \n"
                  "code on his computer")
        if cmd.upper() == "COUNT TO A NUMBER":
            no = int(input("what is your number>>"))
            for nom in range(no + 1):
                print(nom)
        if cmd == "bye":
            break
        if cmd == "what is the stonehenge":
            print(
                '''the stonehenge is an ancient monument having large 
            stones placed in a circular shape each stone of the 
            monument is super heavy and it remains a mystery till now
            how the stones were placed there the monument is 
            perfectly alligned to show the first sunrise of summer solstice''')
        else:
            print(f"sorry i didn't get <{cmd}>, please try again..")
        if cmd == "bye":
            print("bye for now but not for long")
            break
except ValueError:
    print("input should be in words")