from ecommerce import shipping
shipping.calculate_shipping()